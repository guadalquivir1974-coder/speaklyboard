# SpeaklyBoard (MVP)

Un **tablero inteligente** en un **único archivo HTML** que convierte texto/transcripción en un **mapa mental** con:
- notas (arrastrables)
- colores
- conexiones con flechas
- auto-layout
- exportación **PNG** y **JSON**

✅ Sin APIs externas.  
✅ Sin Web Speech.  
⚠️ Para transcripción **100% offline**, necesitas cargar **un modelo** y **un runtime WASM** compatible (por ejemplo, un build web de *whisper.cpp*). Este repositorio incluye el *adaptador*; tú aportas los archivos runtime/modelo desde tu equipo (no se suben a ningún servidor).

---

## 1) Cómo ejecutar (recomendado: GitHub Codespaces)

### Opción A — Abrir como archivo (rápido)
1. Abre `SpeaklyBoard.html`
2. Doble click (en local) o usa “Preview” si tu entorno lo permite

> Nota: algunos navegadores restringen ciertas funciones al abrir `file://`. Si algo falla, usa la opción B.

### Opción B — Servidor local (más compatible)
En Codespaces o local:

```bash
python3 -m http.server 8000
```

Luego abre el puerto 8000 y visita:
`http://localhost:8000/SpeaklyBoard.html`

---

## 2) Uso básico
1. (Opcional) Pulsa **✨ Generar mapa mental** con el texto de ejemplo.
2. Graba audio (**🎙️ Grabar**) o sube un archivo de audio.
3. Pega texto o usa **🧠 Transcribir (offline)** si tienes modelo+runtime cargados.
4. Conecta notas con **🔗 Conectar** (clic origen, clic destino).
5. Exporta:
   - **🖼️ Exportar PNG**
   - **⬇️ Exportar JSON**

---

## 3) Transcripción offline (sin Web Speech, sin APIs)

### Qué archivos tienes que cargar
En la barra lateral:
- **Modelo Whisper**: un archivo local del modelo (ej: tiny/base).
- **Runtime WASM**: dos archivos locales:
  - `whisper.wasm`
  - `whisper.worker.js` (o similar)

> SpeaklyBoard no descarga nada: tú eliges archivos locales desde tu disco.

### Protocolo mínimo que debe soportar el worker
El HTML crea un `Worker` con el contenido de tu `whisper.worker.js` y le envía:

- `init`:
  - `wasm`: ArrayBuffer
  - `model`: ArrayBuffer
- `transcribe`:
  - `audioPcmF32`: ArrayBuffer (Float32 mono, 16kHz)
  - `sampleRate`: number

El worker debe responder:
- `{ type: "ready" }`
- `{ type: "result", text: "..." }`
- `{ type: "error", error: "..." }`

Si tu worker usa otro API, adapta tu worker a este protocolo (es el punto de integración).

---

## 4) Guardar / Reabrir
- Exporta a JSON (**⬇️ Exportar JSON**)
- Importa ese JSON (**⬆️ Importar JSON**) para recuperar notas y conexiones

---

## 5) Notas
Este MVP está hecho para ser **1 HTML** autocontenido.  
En la siguiente iteración (cuando lo confirmes) puedo integrar directamente dentro del HTML:
- un runtime WASM específico (embebido en base64) para que sólo tengas que cargar el **modelo** (más cercano a “autocontenido total”).
