# SpeaklyBoard (MVP)

Una pizarra inteligente en **un solo archivo HTML autocontenido** que convierte voz en notas visuales con conexiones, modo pizarra / mapa mental y exportación.

## Requisitos
- **Chrome o Edge** (recomendado) para Web Speech API.
- No necesita instalar nada.

## Ejecutar (local)
1. Abre `index.html` con doble click.
2. Permite el micrófono cuando te lo pida el navegador.
3. Pulsa **Iniciar** y habla.

## Ejecutar en GitHub Codespaces (recomendado)
1. Sube este proyecto a GitHub (ver pasos abajo).
2. Abre el repo → **Code** → **Codespaces** → **Create codespace**.
3. En el panel de archivos, haz click derecho sobre `index.html` → **Open with Live Server** (si está disponible),
   o instala la extensión "Live Server", o usa:
   - Terminal: `python -m http.server 8000`
   - Pestaña **PORTS** → abre el puerto 8000
   - En el navegador: abre `/index.html`

> Nota: algunos navegadores bloquean el micrófono si abres el HTML con `file://`. Si te ocurre, usa el servidor simple (`python -m http.server`) y ábrelo con `http://`.

## Comandos por voz (ejemplos)
- `nueva nota: ...` / `nota: ...`
- `título: ...` (nodo central en mapa mental)
- `conectar A con B`
- `color rojo|azul|verde|amarillo|morado|gris`
- `modo pizarra` / `modo mapa`

## Exportar / Importar
- **PNG**: imagen de la pizarra (render local).
- **JSON**: guardar y reimportar.
- **HTML**: snapshot para compartir (sin micrófono).

## Archivos
- `index.html` — app completa
